import requests
from bs4 import BeautifulSoup

# URL to scrape
url = "http://quotes.toscrape.com"

# Send HTTP GET request
response = requests.get(url)

# Parse HTML content
soup = BeautifulSoup(response.text, 'html.parser')

# Extract all quotes and authors on the page
quotes = soup.find_all('div', class_='quote')

# Display results
for quote in quotes:
    text = quote.find('span', class_='text').text
    author = quote.find('small', class_='author').text
    print(f"Quote: {text}")
    print(f"Author: {author}")
    print('-' * 50)

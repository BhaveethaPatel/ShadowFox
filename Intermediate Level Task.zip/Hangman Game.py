import random

# 1. Word list with hints
words = [
    ("python", "A popular programming language"),
    ("ironman", "A Marvel superhero in a suit"),
    ("pizza", "A famous Italian dish"),
    ("jupiter", "Largest planet in our solar system"),
    ("guitar", "A musical instrument with strings")
]

# 2. Choose a random word and hint
word, hint = random.choice(words)
guessed = ["_"] * len(word)
attempts = 7
used_letters = []

# 3. Game loop
print("Welcome to Hangman!")
print("Hint:", hint)

while attempts > 0 and "_" in guessed:
    print("\nWord:", " ".join(guessed))
    print("Attempts left:", attempts)
    print("Used letters:", ", ".join(used_letters))

    guess = input("Guess a letter: ").lower()

    if len(guess) != 1 or not guess.isalpha():
        print("Enter a single alphabet only.")
        continue

    if guess in used_letters:
        print("You already guessed that letter.")
        continue

    used_letters.append(guess)

    if guess in word:
        print("Good guess!")
        for i, letter in enumerate(word):
            if letter == guess:
                guessed[i] = guess
    else:
        print("Wrong guess.")
        attempts -= 1

# 4. Result
print("\nWord:", " ".join(guessed))
if "_" not in guessed:
    print("Congratulations! You guessed it right!")
else:
    print("Game Over! The word was:", word)

'''1. Create a variable named pi and store the value 22/7 in it.
 Now check the data type of this variable. '''
pi = 22 / 7
print("Value of pi:", pi)
print("Data type of pi:", type(pi))


'''2. Create a variable called for and assign it a value 4. See what
 happens and find out the reason behind the behavior that you
 see.'''
for = 4
# except SyntaxError: Cannot use 'for' as a variable name because it is a reserved keyword


'''3. Store the principal amount, rate of interest, and time in
 different variables and then calculate the Simple Interest for 3
 years. Formula: Simple Interest = P x R x T / 100 create this code and
 give without any plagarism it should execute  give correct code without
 comment lines'''
principal = 15000
rate = 4
time = 5
simple_interest = (principal * rate * time) / 100
print("The Simple Interest for {time} years at {rate}% rate on ₹{principal} is: ₹{simple_interest}")

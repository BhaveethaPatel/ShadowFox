'''1. Roll a 6-sided die 20 times and count:
- How many times 6 was rolled
- How many times 1 was rolled
- How many times two 6s appeared in a row'''
import random
count_6 = 0
count_1 = 0
count_2sixes = 0
previous = 0
for i in range(20):
    roll = random.randint(1, 6)
    if roll == 6:
        count_6 += 1
        if previous == 6:
            count_2sixes += 1
    if roll == 1:
        count_1 += 1
    previous = roll
print("6s rolled:", count_6)
print("1s rolled:", count_1)
print("Two 6s in a row:", count_2sixes)

'''2. Jumping jacks workout tracker: Do 100 in sets of 10 with tired check'''

total = 0
for i in range(10):
    total += 10
    print(f"Completed {total} jumping jacks.")
    tired = input("Are you tired? (yes/no): ").lower()
    if tired in ["yes", "y"]:
        skip = input("Do you want to skip the rest? (yes/no): ").lower()
        if skip in ["yes", "y"]:
            print(f"You completed a total of {total} jumping jacks.")
            break
    if total == 100:
        print("Congratulations! You completed the workout.")

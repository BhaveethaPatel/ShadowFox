'''1. Create a list of your friends' names and a list of tuples with name and name length'''

friends_list = ["Pooja", "Manish", "Revathi", "Rahul", "Akhila"]
name_info = [(friend, len(friend)) for friend in friends_list]
print("Friends and their name lengths:", name_info)

'''2. Trip expense tracker using two dictionaries, compare totals, and find major differences'''
my_expenses = {
    "Hotel": 2200,
    "Food": 600,
    "Transport": 400,
    "Attractions": 500,
    "Extras": 200
}

friend_expenses = {
    "Hotel": 2000,
    "Food": 900,
    "Transport": 500,
    "Attractions": 400,
    "Extras": 350
}

my_total = sum(my_expenses.values())
friend_total = sum(friend_expenses.values())

print("\nMy Total Expenses: ₹", my_total)
print("Friend's Total Expenses: ₹", friend_total)

if my_total > friend_total:
    print("I spent more on the trip.")
elif my_total < friend_total:
    print("My friend spent more on the trip.")
else:
    print("We both spent equally.")


# Calculate largest difference in a single category
largest_gap = 0
category_with_max_gap = ""

for item in my_expenses:
    gap = abs(my_expenses[item] - friend_expenses[item])
    if gap > largest_gap:
        largest_gap = gap
        category_with_max_gap = item

print(f"The biggest difference in spending is on '{category_with_max_gap}' with ₹{largest_gap} difference.")
'''1. Write a function that takes two arguments, 145 and 'o', and
uses the `format` function to return a formatted string. Print the
result. Try to identify the representation used.'''
def custom_format(value, formt):
    return format(value, formt)
result = custom_format(145, 'o')
print(result)


'''2. In a village, there is a circular pond with a radius of 84 meters.
Calculate the area of the pond using the formula: Circle Area = π
r^2. (Use the value 3.14 for π)
Bonus Question: If there is exactly 1.4 liters of water in a square meter,
what is the total amount of water in the pond? Print the answer without any decimal point in it.'''
radius = 84
pi = 3.14
area = pi * radius * radius
water_liters = 1.4
total_water = int(area * water_liters)
print(total_water)


'''3. If you cross a 490 meter long street in 7 minutes, calculate your
speed in meters per second. Print the answer without any decimal
point in it.'''
distance = 490
t_minutes = 7
t_seconds = t_minutes * 60
speed = int(distance / t_seconds)
print(speed)

'''1. Calculate the number of members in the Justice League.'''
league_members = ["Superman", "Batman", "Wonder Woman", "Flash", "Aquaman", "Green Lantern"]
print(len(league_members))


'''2. Batman recruited Batgirl and Nightwing as new members. Add them to your list.'''
league_members+= ["Batgirl", "Nightwing"]
print(league_members)


'''3. Wonder Woman is now the leader of the Justice League. Move her to the beginning of the list.'''
league_members.remove("Wonder Woman")
league_members.insert(0, "Wonder Woman")
print(league_members)


'''4. Aquaman and Flash are having conflicts, and you need to separate them. 
Choose either "Green Lantern" or "Superman" and move them in between Aquaman and Flash.'''
league_members.remove("Green Lantern")
pops_flash = league_members.index("Flash")
league_members.insert(pops_flash, "Green Lantern")
print(league_members)


'''5. The Justice League faced a crisis, and Superman decided to assemble a new team.
Replace the existing list with the following new members: 
"Cyborg", "Shazam", "Hawkgirl", "Martian Manhunter", "Green Arrow".'''
league_members = ["Cyborg", "Shazam", "Hawkgirl", "Martian Manhunter", "Green Arrow"]
print(league_members)


'''6. Sort the Justice League alphabetically. The hero at the 0th index will become the new leader.'''
league_members.sort()
print(league_members)


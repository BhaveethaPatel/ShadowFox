'''1. Create a class Avenger and six superheroes with their details.'''

# 1. Create a class called Avenger to represent Marvel’s superheroes
class Avenger:
    def __init__(self, name, age, gender, super_power, weapon):
        self.name = name
        self.age = age
        self.gender = gender
        self.super_power = super_power
        self.weapon = weapon

    # Method to display superhero details
    def get_info(self):
        print(f"Name: {self.name}")
        print(f"Age: {self.age}")
        print(f"Gender: {self.gender}")
        print(f"Super Power: {self.super_power}")
        print(f"Weapon: {self.weapon}")
        print()

    # Method to check if the superhero is a leader
    def is_leader(self):
        if self.name == "Captain America":
            print(f"{self.name} is the leader of the Avengers.\n")
        else:
            print(f"{self.name} is not the leader.\n")

# 2. List of six Avengers
super_heroes = ["Captain America", "Iron Man", "Black Widow", "Hulk", "Thor", "Hawkeye"]

# 3. Each Avenger has Name, Age, Gender, Super Power, Weapon (already handled in class)

# 4 & 5. Creating six Avenger objects with appropriate super powers and weapons
captain = Avenger("Captain America", 106, "Male", "Super strength", "Shield")
ironman = Avenger("Iron Man", 49, "Male", "Technology", "Armor")
widow = Avenger("Black Widow", 36, "Female", "Superhuman", "Batons")
hulk = Avenger("Hulk", 41, "Male", "Unlimited Strength", "No Weapon")
thor = Avenger("Thor", 1501, "Male", "Super Energy", "Mjölnir")
hawkeye = Avenger("Hawkeye", 39, "Male", "Fighting Skills", "Bow and Arrows")

# 6. Get information and check leadership status
captain.get_info()
ironman.get_info()
widow.get_info()
hulk.get_info()
thor.get_info()
hawkeye.get_info()

# 7. Check who is the leader
captain.is_leader()
ironman.is_leader()

'''1. Create inheritance using MobilePhone as base class and Apple & Samsung as child classes'''
# 1. Base class MobilePhone with properties and basic functions
class MobilePhone:
    def __init__(self, screen_type, network_type, dual_sim, front_camera, rear_camera, ram, storage):
        self.screen_type = screen_type
        self.network_type = network_type
        self.dual_sim = dual_sim
        self.front_camera = front_camera
        self.rear_camera = rear_camera
        self.ram = ram
        self.storage = storage

    def make_call(self, number):
        print(f"Dialling {number}...")

    def receive_call(self, number):
        print(f"Incoming call from {number}...")

    def take_a_picture(self):
        print(f"Picture taken with {self.rear_camera} rear camera")

# 2. Apple class inherits from MobilePhone using super()
class Apple(MobilePhone):
    def __init__(self, model, front_camera, rear_camera, ram, storage):
        super().__init__("Touch Screen", "5G", False, front_camera, rear_camera, ram, storage)
        self.brand = "Apple"
        self.model = model

    def show_info(self):
        print(f"{self.brand} {self.model} → {self.ram} RAM, {self.storage} Storage, Rear: {self.rear_camera}")

# 3. Samsung class inherits from MobilePhone using super()
class Samsung(MobilePhone):
    def __init__(self, model, dual_sim, front_camera, rear_camera, ram, storage):
        super().__init__("Touch Screen", "4G", dual_sim, front_camera, rear_camera, ram, storage)
        self.brand = "Samsung"
        self.model = model

    def show_info(self):
        print(f"{self.brand} {self.model} → Dual SIM: {self.dual_sim}, RAM: {self.ram}, Rear: {self.rear_camera}")

# 4. Creating Apple objects
apple1 = Apple("iPhone 13", "12MP", "48MP", "4GB", "64GB")
apple2 = Apple("iPhone XR", "7MP", "12MP", "3GB", "64GB")

# 5. Creating Samsung objects
samsung1 = Samsung("Galaxy S22", True, "10MP", "64MP", "8GB", "128GB")
samsung2 = Samsung("Galaxy A10", True, "5MP", "48MP", "2GB", "32GB")

# Testing functionality
apple1.show_info()
apple1.make_call("9876543210")
apple1.take_a_picture()

print()

samsung1.show_info()
samsung1.receive_call("1223366890")
samsung1.take_a_picture()

